// @ts-check
/* eslint-disable */

function output(t) {
  document.write('<p>' + t + '</p>');
}

alert('Hello, World!');
console.log('Hello, World!');
output('Hello, World!');
