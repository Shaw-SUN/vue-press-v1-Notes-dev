import { shellSort } from '../../../../src/js/index';
import { testSortAlgorithm } from './sort-algorithm-tests';

testSortAlgorithm(shellSort, 'Shell Sort');

