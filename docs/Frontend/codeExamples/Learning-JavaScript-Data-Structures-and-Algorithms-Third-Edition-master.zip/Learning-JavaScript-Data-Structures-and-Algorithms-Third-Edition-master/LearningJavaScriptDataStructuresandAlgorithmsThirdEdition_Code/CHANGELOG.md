# Change Log
All notable changes to the "javascript-datastructures-algorithms" third edition source code bundle will be documented in this file.

Based on [Keep a Changelog](http://keepachangelog.com/).

## [Unreleased]
- Initial release
