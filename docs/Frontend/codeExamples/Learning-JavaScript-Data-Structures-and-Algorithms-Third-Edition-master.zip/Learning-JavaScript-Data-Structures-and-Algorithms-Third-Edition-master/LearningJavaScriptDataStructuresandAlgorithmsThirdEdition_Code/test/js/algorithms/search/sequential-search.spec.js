import { sequentialSearch } from '../../../../src/js/index';
import { testSearchAlgorithm } from './search-algorithms-tests';

testSearchAlgorithm(sequentialSearch, 'Sequential Search');
